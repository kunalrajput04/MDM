import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ConsumerMeterInfo } from 'src/app/Model/consumer-meter-info';
import { Member } from 'src/app/Model/group';
import { HeaderMenu } from 'src/app/Model/header-menu';
import { ITariffRequestAdd } from 'src/app/Model/iservice-request-add';
import { AuthService } from 'src/app/Service/auth.service';
import { DTService } from 'src/app/Service/dt.service';
import { FeederService } from 'src/app/Service/feeder.service';
import { GroupService } from 'src/app/Service/group.service';
import { ServiceRequestService } from 'src/app/Service/service-request.service';
import { SmartMeterService } from 'src/app/Service/smart-meter.service';
import { SubdivisionService } from 'src/app/Service/subdivision.service';
import { SubstationService } from 'src/app/Service/substation.service';
import { Utility } from 'src/app/Shared/utility';

@Component({
  selector: 'app-add-tariff',
  templateUrl: './add-tariff.component.html',
  styleUrls: ['./add-tariff.component.css'],
})
export class AddTariffComponent implements OnInit {
  //#region  menu
  datas: HeaderMenu = {
    firstlevel: 'Instant Demand Service',
    levelurl: '',
    menuname: 'Add Tarrif',
    url: '/mdm/prepaid',
  };

  subdivisionDropDown: any[] = [];
  substatioDropDown: any[] = [];
  feederDropDown: any[] = [];
  dtDropDown: any[] = [];
  formData: ITariffRequestAdd = {
    requestID: 0,
    sectionLoad: '',
    requestByName: localStorage.getItem('Name'),
    requestReason: '',
    requestType: '',
    requestValue: '',
    response: '',
    remarks: '',
    requestTo: '',
    consumerNumber: '',
    requestStatus: 'Pending',
    oldTariff: '0',
    newTariff: '0',
    accessLevel: localStorage.getItem('AccessLevel'),
    accessValue: localStorage.getItem('AccessValue'),
  };
  utility = new Utility();
  subdivisonName: string = '';
  substationName: string = '';
  feederName: string = '';
  dtName: string = '';

  consumerGroup: string = '';
  members: Member[] = [];

  constructor(
    private service: ServiceRequestService,
    private userservice: GroupService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private subdivisionservice: SubdivisionService,
    private substation: SubstationService,
    private feederservice: FeederService,
    private dtservice: DTService,
    private authservice: AuthService
  ) {
    this.authservice.chagneHeaderNav(this.datas);
  }
  ngOnInit(): void {
    this.getMembers();
    this.getSubdivision();
  }

  getMembers() {
    this.userservice.getMembers().subscribe(
      (res: any) => {
        this.members = res.data;
      },
      (err) => {}
    );
  }
  manageRequest() {
    this.spinner.show();
    if (this.formData.requestType == 'ConsumerGroup') {
      this.formData.requestValue = this.consumerGroup;
    }
    if (this.formData.requestType == 'SUBDEVISION') {
      this.formData.requestValue = this.subdivisonName;
    }
    if (this.formData.requestType == 'SUBSTATION') {
      this.formData.requestValue = this.substationName;
    }
    if (this.formData.requestType == 'FEEDER') {
      this.formData.requestValue = this.feederName;
    }
    if (this.formData.requestType == 'DT') {
      this.formData.requestValue = this.dtName;
    }

    this.service.manageTariffRequest(this.formData).subscribe(
      (res: any) => {
        if (res.success == true) {
          this.toastr.success(res.message);
          this.router.navigate(['/mdm/prepaid/tariff']);
        } else {
          this.toastr.error(res.message);
        }
        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        if (err.status == 400) this.toastr.error(err);
      }
    );
  }

  getSubdivision() {
    this.spinner.show();

    this.subdivisionservice.getSubdivision().subscribe((res: any) => {
      this.spinner.hide();
      if (
        res != null &&
        res.message != 'Key Is Not Valid' &&
        res.message != 'Session Is Expired'
      ) {
        this.utility.updateApiKey(res.apiKey);;
        this.subdivisionDropDown = [];
        let obj = res.data[0];
        for (var item in obj) {
          this.subdivisionDropDown.push(obj[item][0]);
        }
      } else {
        
        this.authservice.logoutUserWhenTokenExpired();
      }
    });
  }
  getSubstation() {
    this.spinner.show();
    this.substation
      .getSubstationBySubdivision(this.subdivisonName)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.substatioDropDown = [];
        if (
          res != null &&
          res.message != 'Key Is Not Valid' &&
          res.message != 'Session Is Expired'
        ) {
          this.utility.updateApiKey(res.apiKey);;
          let obj = res.data[0];
          for (var item in obj) {
            this.substatioDropDown.push(obj[item][0]);
          }
        } else {
          this.spinner.hide();
          this.authservice.logoutUserWhenTokenExpired();
        }
      });
  }
  getFeeder() {
    this.spinner.show();
    this.feederservice
      .getFeederBySubstation(this.substationName)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.feederDropDown = [];
        if (
          res != null &&
          res.message != 'Key Is Not Valid' &&
          res.message != 'Session Is Expired'
        ) {
          this.utility.updateApiKey(res.apiKey);;
          let obj = res.data[0];
          for (var item in obj) {
            this.feederDropDown.push(obj[item][0]);
          }
        } else {
          this.spinner.hide();
          this.authservice.logoutUserWhenTokenExpired();
        }
      });
  }
  getDT() {
    this.spinner.show();
    this.dtservice.getDTByFeeder(this.feederName).subscribe((res: any) => {
      this.spinner.hide();
      this.dtDropDown = [];
      if (
        res != null &&
        res.message != 'Key Is Not Valid' &&
        res.message != 'Session Is Expired'
      ) {
        this.utility.updateApiKey(res.apiKey);;
        let obj = res.data[0];
        for (var item in obj) {
          this.dtDropDown.push(obj[item][0]);
        }
      } else{
        this.spinner.hide();
        this.authservice.logoutUserWhenTokenExpired();
      } 
    });
  }
}
