import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { Member } from 'src/app/Model/group';
import { IServiceRequest } from 'src/app/Model/iservice-request';
import { IServiceRequestAdd, ITariffRequestAdd, UploadAtAccessLevel } from 'src/app/Model/iservice-request-add';
import { DTService } from 'src/app/Service/dt.service';
import { FeederService } from 'src/app/Service/feeder.service';
import { GroupService } from 'src/app/Service/group.service';
import { ServiceRequestService } from 'src/app/Service/service-request.service';
import { SubdivisionService } from 'src/app/Service/subdivision.service';
import { SubstationService } from 'src/app/Service/substation.service';

@Component({
  selector: 'app-tariff-category',
  templateUrl: './tariff-category.component.html',
  styleUrls: ['./tariff-category.component.css']
})
export class TariffCategoryComponent implements OnInit {
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  rowdata: IServiceRequest[] = [];
  isAdd: boolean = false;
  
  accessform:UploadAtAccessLevel={
    accessLevel: 'ALL',     
    subdivisonName: '',
    substationName: '',
    feederName: '',
    dtName: ''
  }

  subdivisionDropDown: any[] = [];
  substatioDropDown: any[] = [];
  feederDropDown: any[] = [];
  dtDropDown: any[] = [];


  
  isAssignUser:boolean=false;
  excelfile1: any;
  @ViewChild('closebutton') closebutton;
  constructor(
    private service: ServiceRequestService,
    private userservice:GroupService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private subdivisionservice: SubdivisionService,
    private substation: SubstationService,
    private feederservice: FeederService,
    private dtservice: DTService
    ) { }

  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      lengthMenu: [10, 25, 50, 100, 500, 1000, 10000],
      scrollY: 400,
      scrollX: true,
      dom: 'lBfrtip',
      processing: true,

      buttons: [
        { extend: 'excel', title: 'Load Data' },
        { extend: 'pdf', title: 'Load Data' },
      ],
    };
    this.onList();
    
  }

  onList() {
    this.spinner.show();
    this.service.getTariffAll().subscribe(
      (res: any) => {
        if (res.success == true) {
          this.rowdata = res.data;
          this.dtTrigger.next();
          
        } else {
          this.toastr.error(res.message);
        }
        this.spinner.hide();
      },
      (err) => {
        if (err.status == 400)
          this.toastr.error(err);
      }
    );

  }
  
  onChange1(data: any) {
    let file = data.target.files;
    this.excelfile1 = file.item(0);
  }
 
  getSubdivision() {
    this.spinner.show();

    this.subdivisionservice.getSubdivision().subscribe((res: any) => {
      if (res != null) {
        this.subdivisionDropDown = [];
        let obj = res.data[0];
        for (var item in obj) {
          this.subdivisionDropDown.push(obj[item][0]);
        }
        this.spinner.hide();
      }
    });
  }
  getSubstation(subdivision: string) {
    this.spinner.show();
    this.substation
      .getSubstationBySubdivision(subdivision)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.substatioDropDown = [];
        if (res.data != null) {
          let obj = res.data[0];
          for (var item in obj) {
            this.substatioDropDown.push(obj[item][0]);
          }
        }
      });
  }
  getFeeder(substation: string) {
    this.spinner.show();
    this.feederservice
      .getFeederBySubstation(substation)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.feederDropDown = [];
        if (res.data != null) {
          let obj = res.data[0];
          for (var item in obj) {
            this.feederDropDown.push(obj[item][0]);
          }
        }
      });
  }
  getDT(feeder: string) {
    this.spinner.show();
    this.dtservice.getDTByFeeder(feeder).subscribe((res: any) => {
      this.spinner.hide();
      this.dtDropDown = [];
      if (res.data != null) {
        let obj = res.data[0];
        for (var item in obj) {
          this.dtDropDown.push(obj[item][0]);
        }
      }
    });
  }




}
